<div class="sidebar" data-color="purple" data-background-color="white" data-image="assets/img/sidebar-1.jpg">      
        <div class="logo">
          <a href="index.php" class="simple-text logo-normal">
                Creative Team
          </a>
       </div>
       <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="index.php">
              <i class="fa fa-inbox"></i>
              <p>Dashboard</p>
            </a>
          </li>
        <!--1 start-->
          <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#teacherhod">
              <i class="fa fa-book"></i>
              	<p>Profile<b class="caret"></b></p>
            </a>
            <div class="collapse" id="teacherhod">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="profile_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Profile</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--1 stop-->    
        <!--2 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#student">
              <i class="fa fa-book"></i>
              	<p>Students<b class="caret"></b></p>
            </a>
            <div class="collapse" id="student">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="user_view.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Register</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="student_request_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Request</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="student_search_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--2 stop--> 
        <!--3 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#coordinatior">
              <i class="fa fa-book"></i>
              	<p>Coordinator<b class="caret"></b></p>
            </a>
            <div class="collapse" id="coordinatior">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="coordinator_teacher_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Teacher(Assign)</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="coordinator_student_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Student(Assign)</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="coordinator_search_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--3 stop-->
        <!--4 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#fund">
              <i class="fa fa-book"></i>
              	<p>Funds<b class="caret"></b></p>
            </a>
            <div class="collapse" id="fund">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="funds_notification_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Notification</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_search_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_status_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Status</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_update_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Update</span>
                  </a>
                </li>
                <!--4-1 start-->
          <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#report">
              <i class="fa fa-book"></i>
              	<p>Report<b class="caret"></b></p>
            </a>
            <div class="collapse" id="report">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_student_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Students</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_subject_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Subject(Funds)</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--4-1 stop-->   
              </ul>
            </div>
          </li> 
        <!--4 stop-->  
        <!--5 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#notification">
              <i class="fa fa-book"></i>
              	<p>Notification<b class="caret"></b></p>
            </a>
            <div class="collapse" id="notification">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="notification_coordinator_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Coordinator</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_student_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Student</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_search_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_update_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Update</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_remove_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Remove</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--5 stop-->
        <!--6 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#feedback">
              <i class="fa fa-book"></i>
              	<p>Feedback<b class="caret"></b></p>
            </a>
            <div class="collapse" id="feedback">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_view_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">View</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_replay_teacherhod.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Replay</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--6 stop-->
        <!--7 start-->
        <li class="nav-item ">
                  <a class="nav-link" href="index.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Logout</span>
                  </a>
        </ul>    
        <!--7 stop-->               
        </ul>
      </div>
</div>