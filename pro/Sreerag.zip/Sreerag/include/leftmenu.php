<div class="sidebar" data-color="purple" data-background-color="white" data-image="assets/img/sidebar-1.jpg">      
        <div class="logo">
          <a href="index.php" class="simple-text logo-normal">
                Creative Team
          </a>
       </div>
       <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="index.php">
              <i class="fa fa-inbox"></i>
              <p>Dashboard</p>
            </a>
          </li>
        <!--1 start-->
          <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#student">
              <i class="fa fa-book"></i>
              	<p>Profile<b class="caret"></b></p>
            </a>
            <div class="collapse" id="student">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="profile_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Profile</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--1 stop-->    
        <!--2 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#students">
              <i class="fa fa-book"></i>
              	<p>Students<b class="caret"></b></p>
            </a>
            <div class="collapse" id="students">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="student_search_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--2 stop--> 
        <!--3 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#funds">
              <i class="fa fa-book"></i>
              	<p>Funds<b class="caret"></b></p>
            </a>
            <div class="collapse" id="funds">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="funds_pay_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Pay</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_search_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_status_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Status</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Report</span>
                  </a>
                </li>
                </ul>
            </div>
          </li>
        <!--3 stop-->   
        <!--4 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#notification">
              <i class="fa fa-book"></i>
              	<p>Notification<b class="caret"></b></p>
            </a>
            <div class="collapse" id="notification">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="notification_search_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--4 stop-->
        <!--5 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#feedback">
              <i class="fa fa-book"></i>
              	<p>Feedback<b class="caret"></b></p>
            </a>
            <div class="collapse" id="feedback">
              <ul class="nav">
              <li class="nav-item ">
                  <a class="nav-link" href="feedback_send_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Send</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_view_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">View</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_replay_student.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Replay</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--5 stop-->
        <!--6 start-->    
        <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="index.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Logout</span>
                  </a>
        </ul>
        <!--6 stop-->               
        </ul>
      </div>
</div>