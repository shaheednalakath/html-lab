<div class="sidebar" data-color="purple" data-background-color="white" data-image="assets/img/sidebar-1.jpg">      
        <div class="logo">
          <a href="index.php" class="simple-text logo-normal">
                Creative Team
          </a>
       </div>
       <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="index.php">
              <i class="fa fa-inbox"></i>
              <p>Dashboard</p>
            </a>
          </li>
        <!--1 start-->
          <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#teacher">
              <i class="fa fa-book"></i>
              	<p>Profile<b class="caret"></b></p>
            </a>
            <div class="collapse" id="teacher">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="profile_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Profile</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--1 stop-->    
        <!--2 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#student">
              <i class="fa fa-book"></i>
              	<p>Student<b class="caret"></b></p>
            </a>
            <div class="collapse" id="student">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="student_search_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--2 stop--> 
        <!--4 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#fund">
              <i class="fa fa-book"></i>
              	<p>Funds<b class="caret"></b></p>
            </a>
            <div class="collapse" id="fund">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="funds_pay_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Pay</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_search_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_status_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Status</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Report</span>
                  </a>
                </li>
                </ul>
            </div>
          </li>  
        <!--5 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#notification">
              <i class="fa fa-book"></i>
              	<p>Notification<b class="caret"></b></p>
            </a>
            <div class="collapse" id="notification">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="notification_search_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--5 stop-->
        <!--6 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#feedback">
              <i class="fa fa-book"></i>
              	<p>Feedback<b class="caret"></b></p>
            </a>
            <div class="collapse" id="feedback">
              <ul class="nav">
              <li class="nav-item ">
                  <a class="nav-link" href="feedback_send_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Send</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_view_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">View</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_replay_teacher.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Replay</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--6 stop-->
        <!--7 start-->    
        <li class="nav-item ">
                  <a class="nav-link" href="index.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Logout</span>
                  </a>
        </ul>    
        <!--7 stop-->               
        </ul>
      </div>
</div>