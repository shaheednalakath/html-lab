<div class="sidebar" data-color="purple" data-background-color="white" data-image="assets/img/sidebar-1.jpg">      
        <div class="logo">
          <a href="index.php" class="simple-text logo-normal">
                Creative Team
          </a>
       </div>
       <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="index.php">
              <i class="fa fa-inbox"></i>
              <p>Dashboard</p>
            </a>
          </li>
        <!--1 start-->
          <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#principal">
              <i class="fa fa-book"></i>
              	<p>Profile<b class="caret"></b></p>
            </a>
            <div class="collapse" id="principal">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="profile_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Profile</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--1 stop-->    
        <!--2 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#department">
              <i class="fa fa-book"></i>
              	<p>Department<b class="caret"></b></p>
            </a>
            <div class="collapse" id="department">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="department_create_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Create</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="department_search_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="department_update_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Update</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--2 stop--> 
        <!--3 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#teacher">
              <i class="fa fa-book"></i>
              	<p>Teacher<b class="caret"></b></p>
            </a>
            <div class="collapse" id="teacher">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="teacher_register_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Register</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="teacher_search_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="teacher_update_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Update</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--3 stop-->
        <!--4 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#student">
              <i class="fa fa-book"></i>
              	<p>Student<b class="caret"></b></p>
            </a>
            <div class="collapse" id="student">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="student_search_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--4 stop-->  
        <!--5 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#coordinator">
              <i class="fa fa-book"></i>
              	<p>Coordinator<b class="caret"></b></p>
            </a>
            <div class="collapse" id="coordinator">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="coordinator_teacher_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Teacher</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="coordinator_student_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Student</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="coordinator_edit_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Edit</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--5 stop-->              
        <!--6 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#funds">
              <i class="fa fa-book"></i>
              	<p>Funds<b class="caret"></b></p>
            </a>
            <div class="collapse" id="funds">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="funds_notification_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Notification</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_search_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_status_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Status</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_update_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Update</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_changehistory_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Change History</span>
                  </a>
                </li>
                <!--6-1 start-->
          <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#report">
              <i class="fa fa-book"></i>
              	<p>Report<b class="caret"></b></p>
            </a>
            <div class="collapse" id="report">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_department_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Department</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_semester_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Semester</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_student_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Students</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="funds_report_subject_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Subject(Funds)</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--6-1 stop-->   
              </ul>
            </div>
          </li> 
        <!--6 stop-->  
        <!--7 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#notification">
              <i class="fa fa-book"></i>
              	<p>Notification<b class="caret"></b></p>
            </a>
            <div class="collapse" id="notification">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="notification_teacher_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Teacher</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_student_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Student</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_search_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Search</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_update_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Update</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="notification_remove_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Remove</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--7 stop-->
        <!--8 start-->
        <li class="nav-item ">
            <a class="nav-link" data-toggle="collapse" href="#feedback">
              <i class="fa fa-book"></i>
              	<p>Feedback<b class="caret"></b></p>
            </a>
            <div class="collapse" id="feedback">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_view_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">View</span>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="feedback_replay_principal.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Replay</span>
                  </a>
                </li>
              </ul>
            </div>
          </li> 
        <!--9 stop-->
        <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="index.php">
                    <span class="sidebar-normal" style="padding-left:35px;">Logout</span>
                  </a>
        </ul>    
        <!--9 stop-->               
        </ul>
      </div>
</div>