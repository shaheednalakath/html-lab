<!DOCTYPE html>
<html lang="en">

<head>
  	<?php include("include/header.php");?>
</head>

<body class="">
  <div class="wrapper ">
   	 <?php include("include/leftmenu.php");?>
    <div class="main-panel">
      <!-- Navbar -->
      <?php include("include/navbar.php");?>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-warning card-header-icon">
                  <div class="card-icon">
                    <i class="fa fa-hotel"></i>
                  </div>
                  <p class="card-category">Funding Events</p>
                  <h3 class="card-title">100
                  </h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <a href="javascript:;">More Details </a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-success card-header-icon">
                  <div class="card-icon">
                    <i class="fa fa-audio-description"></i>
                  </div>
                  <p class="card-category">Auditorium</p>
                  <h3 class="card-title">50</h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <a href="javascript:;">More Details </a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-danger card-header-icon">
                  <div class="card-icon">
                    <i class="fa fa-user"></i>
                  </div>
                  <p class="card-category">Users</p>
                  <h3 class="card-title">75</h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                   	<a href="javascript:;">More Details </a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-header card-header-info card-header-icon">
                  <div class="card-icon">
                    <i class="fa fa-money"></i>
                  </div>
                  <p class="card-category">Donation</p>
                  <h3 class="card-title">245</h3>
                </div>
                <div class="card-footer">
                  <div class="stats">
                    <a href="javascript:;">More Details </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-12 col-md-12">
              <div class="card">
                <div class="card-header card-header-tabs card-header-primary">
                  <div class="nav-tabs-navigation">
                    <div class="nav-tabs-wrapper">
                      <span class="nav-tabs-title">Latest Donation</span>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="tab-content">
                    <div class="tab-pane active" id="profile">
                      <table class="table">
                      	<thead>
                        	<tr>
                            	<th>#</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Location</th>
                                <th>Quantity</th>
                                <th>Photo</th>
                                <th>Description</th>
                                <th>Date</th>
                                <th>Time</th>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody>
                          <tr>                           
                            <td>1</td>
                            <td>Abc</td>
                            <td>9847123654</td>
                            <td>Palakkad</td>
                            <td>25</td>
                            <td>Image</td>
                            <td>Hi</td>
                            <td>12-2-2021</td>
                            <td>12.30</td>
                            <td class="td-actions text-right">
                              <button type="button" rel="tooltip" title="Edit Task" class="btn btn-primary btn-link btn-sm">
                                <i class="fa fa-edit"></i>
                              </button>
                              <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                <i class="fa fa-close"></i>
                              </button>
                            </td>
                          </tr>                          
                        </tbody>
                      </table>
                    </div>                   
                  </div>
                </div>
              </div>
            </div>
          
          </div>
        </div>
      </div>
     <?php include("include/footer.php");?> 
    </div>
  </div>
 	
   <?php include("include/js.php");?>
</body>

</html>