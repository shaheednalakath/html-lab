<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php"><h4>WHEEL</h4></a>
                <a class="navbar-brand hidden" href="index.php"><img src="../images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>USERS </a>
                        
                    </li>
 


                   

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>NEW</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_register.php"> register</a></li>     
                                                         
                            </ul>
                    </li>


                  
                   
                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>forgotpassword</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_forgot.php"> forgot</a></li>     
                                                           
                            </ul>
                    </li>



                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>profile</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_register.php"> profile</a></li>     
                                                     
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>register</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_vehical.php"> vehical</a></li>     
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_search.php"> search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_remove.php"> remove</a></li>                               
                                                        
                            </ul>
                    </li>

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>fuel</a>
                            <ul class="sub-menu children dropdown-menu">    
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_fuel_search.php"> search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_fuel_order.php"> order</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_fuel_invoice.php"> invoice</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_fuel_report.php"> report</a></li>  
                             
                                                           
                                                        
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>workshop</a>
                              
                            <ul class="sub-menu children dropdown-menu">    
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_workshop_search.php"> search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="edit.php"> edit</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="invoice.php"> invoice</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_workshop_report.php"> report</a></li>  
                             
                                                           
                                                        
                                    
                                                        
                            </ul>
                    </li>



                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>insurance</a>
                            <ul class="sub-menu children dropdown-menu">   
                                
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_insurance_search.php"> search</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="invoice.php"> invoice</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_insurance_report.php"> report</a></li>  
                             
                                                           
                                                        
                                                         
                                                        
                            </ul>
                    </li>




                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>pollution</a>
                            <ul class="sub-menu children dropdown-menu">   
                                
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_polution_search.php"> search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php"> edit</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php"> invoice</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_polution_report.php"> report</a></li>  
                             
                                                           
                                                        
                            </ul>                              
                                                        
                            
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>tax and text</a>
                            <ul class="sub-menu children dropdown-menu">   
                            
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_taxatext_search.php"> search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_.php"> edit</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php"> invoice</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_taxatext_report.php"> report</a></li>  
                             
                                                           
                                                        
                                                  
                                                        
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>spare parts</a>
<ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_spareparts_search.php">search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php">order</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php">invoice</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_spareparts_report.php">report</a></li>                 
                                                        
                            </ul>
                    </li>



                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>notification</a>
<ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_notification_insurance.php">insurance</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php">pollution</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php">tax</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php">test</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php">maintains</a></li>
                                            
                                                        
                            </ul>
                    </li>
                    

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>feedback</a>
<ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_feedback_send.php">send</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_feedback_view.php">view</a></li>
                            <li><i class="menu-icon fa fa-th"></i><a href="user_pan_feedback_replay.php">replay</a></li>
                                            
                                                        
                            </ul>
                    </li>






               
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>