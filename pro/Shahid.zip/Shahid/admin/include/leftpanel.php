<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php"><h4>WHEEL</h4></a>
                <a class="navbar-brand hidden" href="index.php"><img src="../images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>ADMINISTATOR </a>
                        
                    </li>
 


                   

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>profile</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="ad_profile.php"> profile</a></li>     
                                                         
                            </ul>
                    </li>


                  
                   
                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>user</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="user_search.php"> search</a></li>     
                            <li><i class="menu-icon fa fa-th"></i><a href="user_report.php"> report</a></li>                               
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>vehicle</a>
                            <ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="vehical_search.php">search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="vehical_report.php"> report</a></li>                               
                                                        
                            </ul>
                    </li>



                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>workshop</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="workshop_search.php"> search</a></li>     
                            <li><i class="menu-icon fa fa-th"></i><a href="workshop_report.php"> report</a></li>                               
                            </ul>
                    </li>
                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>orders</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="order_search.php"> search</a></li>     
                            <li><i class="menu-icon fa fa-th"></i><a href="order_report.php"> report</a></li>                               
                            </ul>
                    </li>

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>product</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="product_search.php"> search</a></li>     
                            <li><i class="menu-icon fa fa-th"></i><a href="product_report.php"> report</a></li>                               
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>payments</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="payment_search.php"> search</a></li>     
                            <li><i class="menu-icon fa fa-th"></i><a href="payment_report.php"> report</a></li>                               
                            </ul>
                    </li>
                   

                  


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>fuel</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="fuel_register.php"> register</a></li>     
                            <li><i class="menu-icon fa fa-th"></i><a href="fuel_search.php"> search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="fuel_report.php"> report</a></li>                               
                                                        
                            </ul>
                    </li>

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>spare parts</a>
                            <ul class="sub-menu children dropdown-menu">    
                            <li><i class="menu-icon fa fa-th"></i><a href="spare_search.php"> search</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="spare_report.php"> report</a></li>                               
                                                        
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>feedback</a>
                            <ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="feedback_view.php">view</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="feedback_reply.php"> replay</a></li>                               
                                                        
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>logout</a>
<ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="ad_logout.php">logout</a></li>  
                                             
                                                        
                            </ul>
                    </li>




               
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
</aside>