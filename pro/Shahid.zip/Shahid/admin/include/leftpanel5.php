<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="index.php"><h4>WHEEL</h4></a>
                <a class="navbar-brand hidden" href="index.php"><img src="../images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php"> <i class="menu-icon fa fa-dashboard"></i>FUEL STATION </a>
                        
                    </li>
 


                   

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>new</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_new_register.php"> register</a></li>     
                                                         
                            </ul>
                    </li>


                  
                   
                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>profile</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_profile_profile.php"> profile</a></li>     
                                                          
                            </ul>
                    </li>

                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>forgotpassword</a>
                            <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_forgot_forgot.php"> forgot</a></li>     
                                                          
                            </ul>
                    </li>

                    


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>order</a>
                            <ul class="sub-menu children dropdown-menu">    
                            <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_order_view.php">view</a></li>  
                            <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_order_report.php">report</a></li>                               
                                                          
                                                           
                                                                               
                                                        
                            </ul>
                    </li>

        


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>feedback</a>
                            <ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_feedback_send.php">send</a></li> 
                            <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_feedback_view.php">view</a></li> 
                             <li><i class="menu-icon fa fa-th"></i><a href="fuelstation_fuel_feedback_replay.php"> replay</a></li>                               
                                                        
                            </ul>
                    </li>


                    <li class="menu-item-has-children dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="menu-icon fa fa-th"></i>logout</a>
<ul class="sub-menu children dropdown-menu">   
                            <li><i class="menu-icon fa fa-th"></i><a href="college_search.php">logout</a></li>  
                                             
                                                        
                            </ul>
                    </li>




               
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>