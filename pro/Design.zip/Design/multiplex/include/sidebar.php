<nav id="mainnav-container">
    <div id="mainnav">
        <div id="mainnav-menu-wrap">
            <div class="nano">
                <div class="nano-content">
                    <ul id="mainnav-menu" class="list-group">
                        <li class="list-header">Navigation</li>
                        <!--Menu list item-->
                        <li>
                            <a href="javascript:void(0)">
                            <i class="fa fa-home"></i>
                            <span class="menu-title">Profile</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="profile.php"><i class="fa fa-caret-right"></i> Profile</a></li>
                            </ul>
                        </li>
                       
                        <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title"> Ticket</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="ticket_register.php"><i class="fa fa-caret-right"></i> Register</a></li>
                                <li><a href="ticket_search.php"><i class="fa fa-caret-right"></i> Search</a></li>
                                <li><a href="ticket_edit.php"><i class="fa fa-caret-right"></i> Edit</a></li>
                                <li><a href="ticket_remove.php"><i class="fa fa-caret-right"></i> Remove</a></li>
                            </ul>
                        <li>   
                        
                        <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title"> Food</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="food_register.php"><i class="fa fa-caret-right"></i> Register</a></li>
                                <li><a href="food_search.php"><i class="fa fa-caret-right"></i> Search</a></li>
                                <li><a href="food_edit.php"><i class="fa fa-caret-right"></i> Edit</a></li>
                                <li><a href="food_remove.php"><i class="fa fa-caret-right"></i> Remove</a></li>
                            </ul>
                        <li>   
                                                 
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title"> Booking</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="booking_request.php"><i class="fa fa-caret-right"></i> Request</a></li>
                                <li><a href="booking_search.php"><i class="fa fa-caret-right"></i> Search</a></li>
                                <li><a href="booking_accept.php"><i class="fa fa-caret-right"></i> Accept</a></li>
                                <li><a href="booking_cancel.php"><i class="fa fa-caret-right"></i> Cancel</a></li>
                            </ul>
                        <li> 
                                               
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title">Report</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                            	<li><a href="booking_report.php"><i class="fa fa-caret-right"></i> Booking</a></li>
                                <li><a href="payment_report.php"><i class="fa fa-caret-right"></i> Payment</a></li>
                            </ul>
                        <li> 
                       
                      
                          <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title">Package</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="package_register.php"><i class="fa fa-caret-right"></i> Add</a></li>
                                <li><a href="package_search.php"><i class="fa fa-caret-right"></i> Search</a></li>
                            </ul>
                        <li> 
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title">Message</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="message_send.php"><i class="fa fa-caret-right"></i> Send</a></li>
                                <li><a href="message_view.php"><i class="fa fa-caret-right"></i> View</a></li>
                            </ul>
                        <li> 
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title">Logout</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="../index.php"><i class="fa fa-caret-right"></i> Logout</a></li>
                            </ul>
                        <li> 
                                           
                    </ul>
               
                </div>
            </div>
        </div>
    </div>
    </nav>