<nav id="mainnav-container">
    <div id="mainnav">
        <div id="mainnav-menu-wrap">
            <div class="nano">
                <div class="nano-content">
                    <ul id="mainnav-menu" class="list-group">
                        <li class="list-header">Navigation</li>
                        <!--Menu list item-->
                        <li>
                            <a href="javascript:void(0)">
                            <i class="fa fa-home"></i>
                            <span class="menu-title">Profile</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="profile.php"><i class="fa fa-caret-right"></i> Profile</a></li>
                            </ul>
                        </li>
                       
                        <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title"> Hotel</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="hotel_search.php"><i class="fa fa-caret-right"></i> Search</a></li>
                                <li><a href="hotel_report.php"><i class="fa fa-caret-right"></i> Report</a></li>
                            </ul>
                        <li>  
                        
                        <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title"> Multiplex</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="multiplex_search.php"><i class="fa fa-caret-right"></i> Search</a></li>
                                <li><a href="hotel_report.php"><i class="fa fa-caret-right"></i> Report</a></li>
                            </ul>
                        <li>    
                        
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title"> User</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="user_search.php"><i class="fa fa-caret-right"></i> Search</a></li>
                                <li><a href="user_report.php"><i class="fa fa-caret-right"></i> Report</a></li>
                            </ul>
                        <li>    
                                                 
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title"> Booking</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="booking_multiplex.php"><i class="fa fa-caret-right"></i> Hotel</a></li>
                                <li><a href="booking_hotel.php"><i class="fa fa-caret-right"></i> Multiplex</a></li>
                                <li><a href="booking_report.php"><i class="fa fa-caret-right"></i> Report</a></li>
                            </ul>
                        <li> 
                                               
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title">Payment</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="hotel_payment_report.php"><i class="fa fa-caret-right"></i> Hotel</a></li>
                                <li><a href="payment_report.php"><i class="fa fa-caret-right"></i> Multiplex</a></li>
                            </ul>
                        <li> 
                       
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title">Message</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="message_view.php"><i class="fa fa-caret-right"></i> View</a></li>
                                <li><a href="message_reply.php"><i class="fa fa-caret-right"></i> Reply</a></li>
                            </ul>
                        <li> 
                         <!--Menu list item-->
                        <li class="list-divider"></li>
                        <li>
                            <a href="#">
                            <i class="fa fa-edit"></i>
                            <span class="menu-title">Logout</span>
                            <i class="arrow"></i>
                            </a>
                            <!--Submenu-->
                            <ul class="collapse">
                                <li><a href="../index.php"><i class="fa fa-caret-right"></i> Logout</a></li>
                            </ul>
                        <li> 
                                           
                    </ul>
               
                </div>
            </div>
        </div>
    </div>
    </nav>