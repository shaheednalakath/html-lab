<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="plugins/switchery/switchery.min.css" rel="stylesheet">
<link href="plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">
<link href="plugins/bootstrap-validator/bootstrapValidator.min.css" rel="stylesheet">
<link href="plugins/jvectormap/jquery-jvectormap.css" rel="stylesheet">
<link href="css/demo/jquery-steps.min.css" rel="stylesheet">
<link href="css/demo/jasmine.css" rel="stylesheet">
<link href="plugins/pace/pace.min.css" rel="stylesheet">
<script src="plugins/pace/pace.min.js"></script>