
// LAYOUT APP V2
// ====================================================================
// This file should not be included in your project.
// This is just a sample how to initialize plugins or components.
//



 $(document).ready(function() {
    $('#appscrolldiv').slimscroll({
        height: '450'
    });

    $('#appscrolldiv3').slimscroll({ 
        height: '585'
	});

    $('#demo-tab-scroll').slimscroll({ 
        height: '450'
	});

    $('#demo-tab-scroll-2').slimscroll({ 
        height: '450'
	});

    $('#demo-tab-scroll-3').slimscroll({ 
        height: '450'
	});

});
