<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multiplex</title>
	<link rel="shortcut icon" href="img/favicon.ico">
		<?php include('include/cs.php'); ?>
</head>
<body>
	<div id="container" class="effect mainnav-lg navbar-fixed mainnav-fixed">
		<?php include('include/header.php'); ?>		
		<div class="boxed">
			<div id="content-container">
				<div class="pageheader">
					<h3><i class="fa fa-home"></i> Dashboard </h3>
						<div class="breadcrumb-wrapper">
							<span class="label">You are here:</span>
							<ol class="breadcrumb">
								<li> <a href="#"> Home </a> </li>
								<li class="active"> Dashboard </li>
							</ol>
						</div>
				</div>
			
            <div id="page-content">                                                                 
				<div class="row">
					<div class="col-lg-3">
						<div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title">All Hotels</h3>
                            </div>
                            <div class="panel-body">                                  
                                <table id="demo-foo-addrow" class="table table-bordered table-hover toggle-circle" data-page-size="7">
                                    <thead>
                                        <tr>
                                            <th>
                                            	<img src="../images/hotels/1.jpg" width="100%" class="img-circle">
                                            </th>                                           
                                        </tr>
                                    </thead>
                                    <tbody>
										
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="10">
                                            	<a href="hotel_search_view.php" class="form-control btn  btn-danger">More</a>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>                            
                            </div>
						</div>
					</div>
				</div>
			</div>
			<?php include('include/sidebar.php'); ?>
		</div>
		<?php include('include/footer.php'); ?>
		<?php include('include/js.php'); ?>
	</div>
</body>
</html>