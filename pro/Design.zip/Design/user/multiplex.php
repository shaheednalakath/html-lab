
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("include/css.php");?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>

    
    <!--HEADER SECTION-->
    <section>       

        <!-- LOGO AND MENU SECTION -->
       	<?php include("include/topmenu.php");?>
		<!-- TOP SEARCH BOX -->
        <?php include("include/search.php");?>
		<!-- END TOP SEARCH BOX -->
    </section>
    <!--END HEADER SECTION-->
	
	<!--DASHBOARD-->
	<section>
		<div class="db">
			<!--LEFT SECTION-->
			<?php include("include/leftmenu.php");?>
			<!--CENTER SECTION-->
			<div class="db-2">
                 <section>
                    <div class="tourz-search">
                        <div class="container" style="width:100%;">
                            <div class="row">
                                <div class="tourz-search-1">
                                    <h1>Search Here Hurry !</h1>
                                    <form class="tourz-search-form" action="multiplex_list.php">
                                        <div class="input-field"  style="width:100%;">
                                            <input type="text" class="autocomplete select-search" placeholder="Location">
                                        </div>
                                        
                                        <div class="input-field pull-right">
                                            <br>
                                            <input type="submit" value="search" class="waves-effect waves-light tourz-sear-btn"> 
                                        </div>
                                    </form>
                                    <div class="tourz-hom-ser">
                                        <ul>
                                            <li>
                                             <a href="#" class="waves-effect waves-light btn-large tourz-pop-ser-btn wow fadeInUp" data-wow-duration="0.5s">
                                             <img src="../images/icon/2.png" alt=""> Tour
                                             </a>
                                            </li>
                                            <li>
                                             <a href="#" class="waves-effect waves-light btn-large tourz-pop-ser-btn wow fadeInUp" data-wow-duration="1s">
                                             <img src="../images/icon/31.png" alt=""> Multiplex
                                             </a>
                                            </li>
                                            <li>
                                             <a href="#" class="waves-effect waves-light btn-large tourz-pop-ser-btn wow fadeInUp" data-wow-duration="1.5s">
                                             <img src="../images/icon/30.png" alt=""> Rentals
                                             </a>
                                            </li>
                                            <li>
                                            <a href="#" class="waves-effect waves-light btn-large tourz-pop-ser-btn wow fadeInUp" data-wow-duration="2s">
                                            <img src="../images/icon/1.png" alt=""> Hotel
                                            </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
			</div>
			<!--RIGHT SECTION-->
			<?php include("include/notification.php");?>
		</div>
	</section>
	<!--END DASHBOARD-->
	
    <!--====== TIPS BEFORE TRAVEL ==========-->
	
	<!--====== FOOTER 1 ==========-->
	<?php include("include/footer.php");?>
	<!--====== FOOTER 2 ==========-->	
	
	<!--========= Scripts ===========-->
	<?php include("include/js.php"); ?>
</body>

</html>