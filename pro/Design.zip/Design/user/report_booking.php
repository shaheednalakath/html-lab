
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("include/css.php");?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>

    
    <!--HEADER SECTION-->
    <section>       

        <!-- LOGO AND MENU SECTION -->
       	<?php include("include/topmenu.php");?>
		<!-- TOP SEARCH BOX -->
        <?php include("include/search.php");?>
		<!-- END TOP SEARCH BOX -->
    </section>
    <!--END HEADER SECTION-->
	
	<!--DASHBOARD-->
	<section>
		<div class="db">
			<!--LEFT SECTION-->
			<?php include("include/leftmenu.php");?>
			<!--CENTER SECTION-->
			<div class="db-2">
				<div class="db-2-com db-2-main">
					<h4>Booking <span class="db-pay-amount">Report</span></h4>
					<div class="db-2-main-com db2-form-pay db2-form-com">
						<div class="db-pay-card">
							<h5>Select Date Ur Needs</h5></div>
						<form class="col s12">							
							<div class="row">
								<div class="input-field col s12 m6">
									<input type="date" class="validate">
								</div>
								<div class="input-field col s12 m6">
									<input type="date" class="validate">
								</div>
							</div>							
							<div class="row">
								<div class="input-field col s12">
									<input type="submit" value="SUBMIT" class="waves-effect waves-light full-btn"> </div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<!--RIGHT SECTION-->
			<?php include("include/notification.php");?>
		</div>
	</section>
	<!--END DASHBOARD-->
	
    <!--====== TIPS BEFORE TRAVEL ==========-->
	
	<!--====== FOOTER 1 ==========-->
	<?php include("include/footer.php");?>
	<!--====== FOOTER 2 ==========-->	
	
	<!--========= Scripts ===========-->
	<?php include("include/js.php"); ?>
</body>

</html>