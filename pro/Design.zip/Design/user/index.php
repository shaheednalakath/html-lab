
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("include/css.php");?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>

    
    <!--HEADER SECTION-->
    <section>       

        <!-- LOGO AND MENU SECTION -->
       	<?php include("include/topmenu.php");?>
		<!-- TOP SEARCH BOX -->
        <?php include("include/search.php");?>
		<!-- END TOP SEARCH BOX -->
    </section>
    <!--END HEADER SECTION-->
	
	<!--DASHBOARD-->
	<section>
		<div class="db">
			<!--LEFT SECTION-->
			<?php include("include/leftmenu.php");?>
			<!--CENTER SECTION-->
			<div class="db-2">
				<div class="db-2-com db-2-main">
					<h4>Manage Booking</h4>
					<div class="db-2-main-com">						
						
                        <div class="db-2-main-1" style="width:50%;">
							<div class="db-2-main-2"> <img src="../images/icon/db3.png" alt="" /><span>Hotel Booking</span>
								<ul>
									<li><a href="db-hotel-details.html">GTC Grand Chola</a>
									</li>
									<li><a href="db-payment.html">Payment Status <span class="db-not-done">not-Done</span></a>
									</li>
									<li><a href="db-hotel-details.html">Remaining Days - 14</a>
									</li>
									<li><a href="db-hotel-details.html">Travel Date - 16 may 2018</a>
									</li>
									<li><a href="db-refund.html">Cancel this booking</a>
									</li>
								</ul>
							</div>
						</div>
                        
						<div class="db-2-main-1" style="width:50%;">
							<div class="db-2-main-2"> <img src="../images/icon/db1.png" alt="" /><span>Multiplex Booking</span>
								<ul>
									<li><a href="db-event-details.html">Eiffel Tower Party</a>
									</li>
									<li><a href="db-payment.html">Payment Status <span class="db-not-done">not-Done</span></a>
									</li>
									<li><a href="db-event-details.html">Remaining Days - 14</a>
									</li>
									<li><a href="db-event-details.html">Travel Date - 16 may 2018</a>
									</li>
									<li><a href="db-refund.html">Cancel this booking</a>
									</li>
								</ul>
							</div>
						</div>
                        
					</div>
				</div>
			</div>
			<!--RIGHT SECTION-->
			<?php include("include/notification.php");?>
		</div>
	</section>
	<!--END DASHBOARD-->
	
    <!--====== TIPS BEFORE TRAVEL ==========-->
	
	<!--====== FOOTER 1 ==========-->
	<?php include("include/footer.php");?>
	<!--====== FOOTER 2 ==========-->	
	
	<!--========= Scripts ===========-->
	<?php include("include/js.php"); ?>
</body>

</html>