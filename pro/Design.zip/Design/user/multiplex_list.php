
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("include/css.php");?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>

    
    <!--HEADER SECTION-->
    <section>       

        <!-- LOGO AND MENU SECTION -->
       	<?php include("include/topmenu.php");?>
		<!-- TOP SEARCH BOX -->
        <?php include("include/search.php");?>
		<!-- END TOP SEARCH BOX -->
    </section>
    <!--END HEADER SECTION-->
	
	<!--DASHBOARD-->
	<section>
		<div class="db">
			<!--LEFT SECTION-->
			<?php include("include/leftmenu.php");?>
			<!--CENTER SECTION-->
			<div class="db-2">
				<div class="db-2-com db-2-main">
					<h4>All Multiplex</h4>
					<div class="db-2-main-com">						
                        
                        <!--RIGHT LISTINGS-->
                            <div class="col-md-12 hot-page2-alp-con-right">
                                <div class="hot-page2-alp-con-right-1">
                                    <!--LISTINGS-->
                                    <div class="row">
                                        <!--LISTINGS START-->
                                        <div class="hot-page2-alp-r-list" style="width:100%;">
                                            <div class="col-md-3 hot-page2-alp-r-list-re-sp">
                                                <a href="javascript:void(0);">
                                                    <div class="hotel-list-score">4.5</div>
                                                    <div class="hot-page2-hli-1"> <img src="../images/hotels/l1.jpeg" alt=""> </div>
                                                    <div class="hom-hot-av-tic hom-hot-av-tic-list"> Available Rooms: 42 </div>
                                                </a>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="hot-page2-alp-ri-p2"> 
                                                	<a href="hotel-details.php"><h3>Universal luxury Grand Hotel</h3>
                                                </a>
                                                    <ul>
                                                        <li>28800 Orchard Lake Road, Suite 180 Farmington Hills, U.S.A.</li>
                                                        <li>+101-1231-1231, +61 6541-4561-12</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="hot-page2-alp-ri-p3">
                                                    <div class="hot-page2-alp-r-hot-page-rat">25%Off</div> 
                                                    <span class="hot-list-p3-1">Price Per Night</span> 
                                                    <span class="hot-list-p3-2">$650</span><span class="hot-list-p3-4">
                                                    <a href="multiplex_details.php" class="hot-page2-alp-quot-btn">Book Now</a>
                                                    </span> 
                                                 </div>
                                            </div>
                                        </div>
                                        <!--END LISTINGS-->
                                    </div>
                                </div>
                            </div>
					<!--END RIGHT LISTINGS-->
					</div>
				</div>
			</div>
			<!--RIGHT SECTION-->
			<?php include("include/notification.php");?>
		</div>
	</section>
	<!--END DASHBOARD-->
	
    <!--====== TIPS BEFORE TRAVEL ==========-->
	
	<!--====== FOOTER 1 ==========-->
	<?php include("include/footer.php");?>
	<!--====== FOOTER 2 ==========-->	
	
	<!--========= Scripts ===========-->
	<?php include("include/js.php"); ?>
</body>

</html>