<div class="search-top">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="search-form">
                <form class="tourz-search-form">
                    <div class="input-field">
                        <input type="text" id="select-city" class="autocomplete">
                        <label for="select-city">Enter city</label>
                    </div>
                    <div class="input-field">
                        <input type="text" id="select-search" class="autocomplete">
                        <label for="select-search" class="search-hotel-type">Search over a million tour and travels, sight seeings, hotels and more</label>
                    </div>
                    <div class="input-field">
                        <input type="submit" value="search" class="waves-effect waves-light tourz-sear-btn"> </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>