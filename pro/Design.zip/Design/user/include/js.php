<script src="../js/jquery-latest.min.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="../js/wow.min.js"></script>
<script src="../js/materialize.min.js"></script>
<script src="../js/custom.js"></script>