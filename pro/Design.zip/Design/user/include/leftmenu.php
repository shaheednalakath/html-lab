<div class="db-l">
    <div class="db-l-1">
        <ul>
            <li><img src="../images/db-profile.jpg" alt="" />
            </li>
            <li><span>80%</span> profile compl</li>
            <li><span>18</span> Notifications</li>
        </ul>
    </div>
    <div class="db-l-2">
        <ul>
            <li>
                <a href="index.php"><img src="../images/icon/db-arrow.png" alt="" /> Home</a>
            </li>
            <li>
                <a href="booking_hotel.php"><img src="../images/icon/db-arrow.png" alt="" / > Hotel</a>
            </li>
            <li>
                <a href="booking_multiplex.php"><img src="../images/icon/db-arrow.png" alt="" /> Multiplex</a>
            </li>
            <li>
                <a href="booking_all.php"><img src="../images/icon/db-arrow.png" alt="" /> Booking</a>
            </li>
            <li>
                <a href="report_booking.php"><img src="../images/icon/db-arrow.png" alt="" /> Report</a>
            </li>
            <li>
                <a href="payment.php"><img src="../images/icon/db-arrow.png" alt="" /> Payments</a>
            </li>
            <li>
                <a href="message_view.php"><img src="../images/icon/db-arrow.png" alt="" /> Message</a>
            </li>
        </ul>
    </div>
    </div>