 <div class="top-logo" data-spy="affix" data-offset-top="250">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="wed-logo">
                    <a href="index.php"><img src="../images/logo.png" alt="" />
                    </a>
                </div>
                <div class="main-menu">
                    <ul>
                        <li><a href="index.php">Home</a></li>  
                        <li><a href="hotel.php">Hotel</a></li>  
                        <li><a href="multiplex.php">Multiplex</a></li>                                           
                        <li><a href="booking_all.php">Booking</a></li> 
                        <li><a href="report_booking.php">Report</a></li> 
                        <li><a href="message_send.php">Message</a></li> 
                        <li><a href="profile.php">Profile</a></li> 
                        <li><a href="../index.php">Logout</a></li> 
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
