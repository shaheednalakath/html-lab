<section>
    <div class="rows">
        <div class="footer1 home_title tb-space">
            <div class="pla1 container">
                <!-- FOOTER OFFER 1 -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="disco">
                        <h3>30%<span>OFF</span></h3>
                        <h4>Eiffel Tower,Rome</h4>
                        <p>valid only for 24th Dec</p> <a href="booking.html">Book Now</a> </div>
                </div>
                <!-- FOOTER OFFER 2 -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="disco1 disco">
                        <h3>42%<span>OFF</span></h3>
                        <h4>Colosseum,Burj Al Arab</h4>
                        <p>valid only for 18th Nov</p> <a href="booking.html">Book Now</a> </div>
                </div>
                <!-- FOOTER MOST POPULAR VACATIONS -->
                <div class="col-md-6 col-sm-12 col-xs-12 foot-spec footer_places">
                    <h4><span>Most Popular</span> Vacations</h4>
                    <ul>
                        <li><a href="index.php">Angkor Wat</a> </li>
                        <li><a href="index.php">Buckingham Palace</a> </li>
                        <li><a href="index.php">High Line</a> </li>
                        <li><a href="index.php">Sagrada Família</a> </li>
                        <li><a href="index.php">Statue of Liberty </a> </li>
                        <li><a href="index.php">Notre Dame de Paris</a> </li>
                        <li><a href="index.php">Taj Mahal</a> </li>
                        <li><a href="index.php">The Louvre</a> </li>
                        <li><a href="index.php">Tate Modern, London</a> </li>
                        <li><a href="index.php">Gothic Quarter</a> </li>
                        <li><a href="index.php">Table Mountain</a> </li>
                        <li><a href="index.php">Bayon</a> </li>
                        <li><a href="index.php">Great Wall of China</a> </li>
                        <li><a href="index.php">Hermitage Museum</a> </li>
                        <li><a href="index.php">Yellowstone</a> </li>
                        <li><a href="index.php">Musée d'Orsay</a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>