
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("include/css.php");?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>

    
    <!--HEADER SECTION-->
    <section>       

        <!-- LOGO AND MENU SECTION -->
       	<?php include("include/topmenu.php");?>
		<!-- TOP SEARCH BOX -->
        <?php include("include/search.php");?>
		<!-- END TOP SEARCH BOX -->
    </section>
    <!--END HEADER SECTION-->
	
	<!--DASHBOARD-->
	<section>
		<div class="db">
			<!--LEFT SECTION-->
			<?php include("include/leftmenu.php");?>
			<!--CENTER SECTION-->
			<div class="db-2">
				<div class="db-2-com db-2-main">
					<h4>Multiplex Details</h4>
					<div class="db-2-main-com">						
                      <!--SECTION START -->
                      	<section style="margin-top:-100px; margin-left:-20px;">
                        <div class="rows inn-page-bg com-colo">
                            <div class="container inn-page-con-bg tb-space">
                                <div class="col-md-12">
								<!--====== TOUR TITLE ==========-->
                                
                                <div class="tour_head" style="width:60%;">
                                    <h2>Universal luxury Grand  
                                        <span class="tour_star">
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star" aria-hidden="true"></i>
                                            <i class="fa fa-star-half-o" aria-hidden="true"></i>
                                        </span>
                                        <span class="tour_rat">4.5</span>
                                    </h2> 
                               </div>
                               
					<!--====== TOUR DESCRIPTION ==========-->
					<div class="tour_head1 hotel-com-color" style="width:60%;">
						<p>Discover two of South America's greatest cities, Rio de Janeiro and Buenos Aires, at a leisurely pace. A major highlight on this journey is a visit to Iguassu Falls in between your two city stays. It truly is one of the most spectacular sights on Earth. See the impressive falls from both the Brazilian and Argentine sides.</p>					
					</div>
					<!--====== ROOMS: HOTEL BOOKING ==========-->
					<div class="tour_head1 hotel-book-room" style="width:60%;">
						<div id="myCarousel1" class="carousel slide" data-ride="carousel">
							<!-- Indicators -->
							<ol class="carousel-indicators carousel-indicators-1">
								<li data-target="#myCarousel1" data-slide-to="0"><img src="../images/gallery/t1.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="1"><img src="../images/gallery/t2.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="2"><img src="../images/gallery/t3.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="3"><img src="../images/gallery/t4.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="4"><img src="../images/gallery/t5.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="5"><img src="../images/gallery/t6.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="6"><img src="../images/gallery/t7.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="7"><img src="../images/gallery/t8.jpg" alt="Chania">
								</li>
								<li data-target="#myCarousel1" data-slide-to="8"><img src="../images/gallery/t9.jpg" alt="Chania">
								</li>
							</ol>
							<!-- Wrapper for slides -->
							<div class="carousel-inner carousel-inner1" role="listbox">
								<div class="item active"><img src="../images/gallery/t1.jpg" alt="Chania" width="345" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t2.jpg" alt="Chania" width="460" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t3.jpg" alt="Chania" width="460" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t4.jpg" alt="Chania" width="460" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t5.jpg" alt="Chania" width="460" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t6.jpg" alt="Chania" width="460" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t7.jpg" alt="Chania" width="460" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t8.jpg" alt="Chania" width="460" height="345"> </div>
								<div class="item"> <img src="../images/gallery/t9.jpg" alt="Chania" width="460" height="345"> </div>
							</div>
							<!-- Left and right controls -->
							<a class="left carousel-control" href="#myCarousel1" role="button" data-slide="prev"> <span><i class="fa fa-angle-left hotel-gal-arr" aria-hidden="true"></i></span> </a>
							<a class="right carousel-control" href="#myCarousel1" role="button" data-slide="next"> <span><i class="fa fa-angle-right hotel-gal-arr hotel-gal-arr1" aria-hidden="true"></i></span> </a>
						</div>
					</div>
					
                    
					<!--====== HOTEL ROOM TYPES ==========-->
					<div class="tour_head1" style="width:60%;">
						<h3 style="margin-left:-40px;">ROOMS & AVAILABILITIES</h3>
						<div class="tr-room-type">
							<ul>
                            
								<li>
									<div class="tr-room-type-list">
										<div class="col-md-3 tr-room-type-list-1">
                                        	<img src="../images/gallery/s7.jpeg" alt="" />
										</div>
										<div class="col-md-6 tr-room-type-list-2">
											<h4>Ultra Deluxe</h4>
											<p><b>Amenities: </b>Television, Wi-Fi</p> 
                                            <span><b>Maxinum </b> : 4 Persons</span> 
                                       </div>
										<div class="col-md-3 tr-room-type-list-3"> 
                                            <span class="hot-list-p3-1">Price</span> 
                                            <span class="hot-list-p3-2">$940</span> 
                                            <a href="multiplex_booking.php" class="hot-page2-alp-quot-btn spec-btn-text">Book Now</a> 
                                        </div>
									</div>
								</li>
                                
							</ul>
						</div>
					</div>
					
					<!--====== TOUR LOCATION ==========-->
					<div class="tour_head1 tout-map map-container" style="width:60%;">
						<h3 style="margin-left:-40px;">Location</h3>
						<iframe src="https://www.google.com/maps/embed" allowfullscreen></iframe>
					</div>
					<div>
						<div class="dir-rat" style="width:60%;">
							<div class="dir-rat-inn">
								<form class="dir-rat-form">
									<div class="form-group col-md-6 pad-left-o">
										<input type="text" class="form-control" id="email11" placeholder="Enter Name"> </div>
									<div class="form-group col-md-6 pad-left-o">
										<input type="number" class="form-control" id="email12" placeholder="Enter Mobile"> </div>
									<div class="form-group col-md-6 pad-left-o">
										<input type="email" class="form-control" id="email13" placeholder="Enter Email id"> </div>
									<div class="form-group col-md-6 pad-left-o">
										<input type="text" class="form-control" id="email14" placeholder="Enter your City"> </div>
									<div class="form-group col-md-12 pad-left-o">
										<textarea placeholder="Write your message"></textarea>
									</div>
									<div class="form-group col-md-12 pad-left-o">
										<input type="submit" value="SUBMIT" class="link-btn"> </div>
								</form>
							</div>
							
							<!--COMMENT RATING-->
							<div class="dir-rat-inn dir-rat-review">
								<div class="row">
									
                                    <div class="col-md-3 dir-rat-left"> 
                                    	<img src="../images/hotels/1.jpg" alt="" style="width:100px;" class="img-circle">
										<p>
                                        	 Orange 
	                                        <span>112-2-2021</span>
                                        </p>
									</div>
									
                                    <div class="col-md-9 dir-rat-right">										
										<p>
                                        	Michael & his team have been helping us with our eqiupment finance for the past.
                                        </p>                                     
								   </div>
                                   
								</div>
							</div>
                          <!--COMMENT RATING-->
                          
						</div>
					</div>
				</div>
			
			</div>
		</div>
	</section>
                      <!--SECTION END-->  
					</div>
				</div>
			</div>
			<!--RIGHT SECTION-->
			<?php include("include/notification.php");?>
		</div>
	</section>
	<!--END DASHBOARD-->
	
    <!--====== TIPS BEFORE TRAVEL ==========-->
	
	<!--====== FOOTER 1 ==========-->
	<?php include("include/footer.php");?>
	<!--====== FOOTER 2 ==========-->	
	
	<!--========= Scripts ===========-->
	<?php include("include/js.php"); ?>
</body>

</html>