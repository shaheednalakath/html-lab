
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include("include/css.php");?>
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>

    
    <!--HEADER SECTION-->
    <section>       

        <!-- LOGO AND MENU SECTION -->
       	<?php include("include/topmenu.php");?>
		<!-- TOP SEARCH BOX -->
        <?php include("include/search.php");?>
		<!-- END TOP SEARCH BOX -->
    </section>
    <!--END HEADER SECTION-->
	
	<!--DASHBOARD-->
	<section>
		<div class="db">
			<!--LEFT SECTION-->
			<?php include("include/leftmenu.php");?>
			<!--CENTER SECTION-->
			<div class="db-2">
				<div class="db-2-com db-2-main">
					<h4>Booking</h4>
					<div class="db-2-main-com">						                        
                     <!--RIGHT LISTINGS-->
                     <section>
                            <div class="tr-register">
                                <div class="tr-regi-form v2-search-form"  style="width:100%;">
                                    <h4>Booking by <span>Name</span></h4>
                                    <p>It's free and always will be.</p>
                                    <form class="contact__form" method="post" action="hotel_payment.php" autocomplete="off">
                                                <div class="alert alert-success contact__msg" style="display: none" role="alert">
                                                    Thank you for arranging a wonderful trip for us! Our team will contact you shortly!
                                                </div>
                                                <div class="row">
                                                    <div class="input-field col s12">
                                                        <input type="text"  class="validate" name="name" required>
                                                        <label>Enter your name</label>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="input-field col s6">
                                                        <input type="number"  class="validate" name="phone" required>
                                                        <label>Enter your phone</label>
                                                    </div>
                                                    <div class="input-field col s6">
                                                        <input type="email"  class="validate" name="email" required>
                                                        <label>Enter your email</label>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="input-field col s12">
                                                        <input type="email"  class="validate" name="email" required>
                                                        <label>Enter your Address</label>
                                                    </div>                                                   
                                                </div>
                                                
                                                <div class="row">
                                                    <div class="input-field col s6">
                                                        <input type="text" id="from" name="arrival" readonly>
                                                        <label for="from">Arrival Date</label>
                                                    </div>
                                                    <div class="input-field col s6">
                                                        <input type="text" id="to" name="departure" readonly>
                                                        <label for="to">Departure Date</label>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="input-field col s6">
                                                        <select name="noofadults">
                                                            <option value="" disabled selected>No of adults</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                            <option value="6">6</option>
                                                        </select>
                                                    </div>
                                                    <div class="input-field col s6">
                                                        <select name="noofchildrens">
                                                            <option value="" disabled selected>No of childrens</option>
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                            <option value="4">4</option>
                                                            <option value="5">5</option>
                                                            <option value="6">6</option>											
                                                        </select>
                                                    </div>
                                                </div>							
                    
                                                <div class="row">
                                                    <div class="input-field col s6">
                                                        <select name="minprice">
                                                            <option value="" disabled selected>Min Price</option>
                                                            <option value="$200">$200</option>
                                                            <option value="$500">$500</option>
                                                            <option value="$1000">$1000</option>
                                                            <option value="$5000">$5000</option>
                                                            <option value="$10,000">$10,000</option>
                                                            <option value="$50,000">$50,000</option>
                                                        </select>
                                                    </div>
                                                    <div class="input-field col s6">
                                                        <select name="maxprice">
                                                            <option value="" disabled selected>Max Price</option>
                                                            <option value="$200">$200</option>
                                                            <option value="$500">$500</option>
                                                            <option value="$1000">$1000</option>
                                                            <option value="$5000">$5000</option>
                                                            <option value="$10,000">$10,000</option>
                                                            <option value="$50,000">$50,000</option>
                                                        </select>
                                                    </div>								
                    
                                                </div>							
                                                <div class="row">
                                                    <div class="input-field col s12">
                                                        <input type="submit" value="Book Now" class="waves-effect waves-light tourz-sear-btn v2-ser-btn">
                                                    </div>
                                                </div>
                                            </form>
                                </div>
                            </div>
                        </section>       
 					 <!--END RIGHT LISTINGS-->
					</div>
				</div>
			</div>
			<!--RIGHT SECTION-->
			<?php include("include/notification.php");?>
		</div>
	</section>
	<!--END DASHBOARD-->
	
    <!--====== TIPS BEFORE TRAVEL ==========-->
	
	<!--====== FOOTER 1 ==========-->
	<?php include("include/footer.php");?>
	<!--====== FOOTER 2 ==========-->	
	
	<!--========= Scripts ===========-->
	<?php include("include/js.php"); ?>
</body>

</html>