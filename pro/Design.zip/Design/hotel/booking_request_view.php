<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Multiplex</title>
	<link rel="shortcut icon" href="img/favicon.ico">
		<?php include('include/cs.php'); ?>
</head>
<body>
	<div id="container" class="effect mainnav-lg navbar-fixed mainnav-fixed">
		<?php include('include/header.php'); ?>		
		<div class="boxed">
			<div id="content-container">
				<div class="pageheader">
					<h3><i class="fa fa-home"></i> Dashboard </h3>
						<div class="breadcrumb-wrapper">
							<span class="label">You are here:</span>
							<ol class="breadcrumb">
								<li> <a href="#"> Home </a> </li>
								<li class="active"> Dashboard </li>
							</ol>
						</div>
				</div>
			
            <div id="page-content">                                                                 
				<div class="row">
					<div class="col-lg-3">
						<div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title">Booking Deatils</h3>
                            </div>
                            <div class="panel-body">                                  
                                <table id="demo-foo-addrow" class="table table-bordered table-hover toggle-circle" data-page-size="7">
                                    <thead>
                                        <tr>
                                            <th>
                                            	<img src="../images/db-profile.jpg" width="100%" class="img-rounded">
                                            </th>                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                    	<tr>
											<td> <b>Room No</b> </td>
                                        </tr>
                                        <tr>
                                        	<td> <b>Customer </b></td>
                                        </tr>
                                        <tr>
                                        	<td> <b>Contact No </b></td>
                                        </tr>
                                        <tr>
                                        	<td> <b>Address </b></td>
                                        </tr>
                                        <tr>
                                        	<td> <b>Check In </b></td>
                                        </tr>
                                        <tr>
                                       		<td> <b>Check Out </b></td>
                                        </tr>
                                         <tr>
                                        	<td> <b>Rs  </b></td>
                                        </tr>
                                        <tr>
                                        	<td> <b>Date </b></td>
                                        </tr>
                                        <tr>
                                        	<td> <b>Status </b></td>
                                        </tr>
                                         <tr>
                                        	<td> 
                                            	<form>
                                                    <select name="stat" class="form-control" required>
                                                    	<option value="">Select</option>
                                                        <option>Accept</option>
                                                        <option>Cancel</option>
                                                    </select>
                                                    <label>Description</label>
                                                    <textarea name="desp"  class="form-control" required></textarea>
                                                    <br>
                                                    <input  type="submit" value="Submit" class="btn btn-block btn-primary">
                                                </form>
	                                        </td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="10">
                                            	<a href="booking_request.php" class="form-control btn  btn-danger">Back</a>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>                            
                            </div>
						</div>
					</div>
				</div>
			</div>
			<?php include('include/sidebar.php'); ?>
		</div>
		<?php include('include/footer.php'); ?>
		<?php include('include/js.php'); ?>
	</div>
</body>
</html>